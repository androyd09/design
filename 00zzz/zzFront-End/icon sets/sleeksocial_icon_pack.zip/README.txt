------------------
SleekSocial Icon Pack
60 Social Icons
PNG Format
Designed by Andrew S. Roberts (ansarob@gmail.com) - http://asroberts.net/
for Design Instruct - http://designinstruct.com/
------------------


These icons are purposely based off of the Adobe Creative Suite logos. I see these being used by grouping them all in one color to match your websites primary color, or using a variety of different colors. Use your creative minds! Icons for the following websites are included: Twitter, Facebook, LinkedIn, Flickr, Digg, RSS, StumbleUpon, Mixx, Google Buzz, and Yahoo Buzz. The colors included are: red, orange, yellow, green, blue, and purple gradients. I would appreciate attribution, but am not requiring it. Hope you find a good use for these!